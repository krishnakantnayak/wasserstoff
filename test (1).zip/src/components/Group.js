import "./Group.css";

const Group = () => {
  return (
    <footer className="group">
      <div className="widget-l-size-timeline-cha1">
        <div className="info5">
          <div className="value12">
            <div className="value13">
              <div className="title17">Sales Figures</div>
              <input className="value14" placeholder="$10,430" type="text" />
            </div>
          </div>
        </div>
        <div className="graph2">
          <div className="chart2">
            <div className="column73" />
            <div className="column74" />
            <div className="column75" />
            <div className="column76" />
            <div className="column77" />
            <div className="column78" />
            <div className="column79" />
            <div className="column80" />
            <div className="column81" />
            <div className="column82" />
            <div className="column83" />
            <div className="column84" />
            <div className="column85" />
            <div className="column86" />
            <div className="column87" />
            <div className="column88" />
            <div className="column89" />
            <div className="column90" />
            <div className="column91" />
            <div className="column92" />
            <div className="column93" />
            <div className="column94" />
            <div className="column95" />
            <div className="column96" />
            <div className="column97" />
            <div className="column98" />
            <div className="column99" />
            <div className="column100" />
            <div className="column101" />
            <div className="column102" />
            <div className="column103" />
            <div className="column104" />
            <div className="column105" />
            <div className="column106" />
            <div className="column107" />
            <div className="column108" />
            <div className="column109" />
            <div className="column110" />
            <div className="column111" />
            <div className="column112" />
            <div className="column113" />
            <div className="column114" />
            <div className="column115" />
            <div className="column116" />
            <div className="column117" />
            <div className="column118" />
            <div className="column119" />
            <div className="column120" />
            <div className="column121" />
            <div className="column122" />
            <div className="column123" />
            <div className="column124" />
            <div className="column125" />
            <div className="column126" />
            <div className="column127" />
            <div className="column128" />
            <div className="column129" />
            <div className="column130" />
            <div className="column131" />
            <div className="column132" />
            <div className="column133" />
            <div className="column134" />
            <div className="column135" />
            <div className="column136" />
            <div className="column137" />
            <div className="column138" />
            <div className="column139" />
            <div className="column140" />
            <div className="column141" />
            <div className="column142" />
            <div className="column143" />
            <div className="column144" />
          </div>
          <div className="line1">
            <div className="bg5" />
            <div className="cian-parent">
              <div className="cian1" />
              <div className="yellow1" />
            </div>
          </div>
        </div>
      </div>
      <div className="footer-description1">
        <div className="footer3">
          <div className="bg6" />
          <b className="orion-data-visualisation3">Orion data visualisation</b>
          <b className="footer-description2">2019</b>
        </div>
        <div className="footer4">
          <div className="bg7" />
          <b className="description1">Orion data visualisation</b>
          <b className="b1">2022</b>
        </div>
      </div>
    </footer>
  );
};

export default Group;
