import "./WidgetLSizeTimelineCha.css";

const WidgetLSizeTimelineCha = () => {
  return (
    <div className="widget-l-size-timeline-cha">
      <div className="info4">
        <div className="value9">
          <div className="value10">
            <div className="title16">Sales Figures</div>
            <input className="value11" placeholder="$10,430" type="text" />
          </div>
        </div>
      </div>
      <div className="graph1">
        <div className="chart1">
          <div className="column" />
          <div className="column1" />
          <div className="column2" />
          <div className="column3" />
          <div className="column4" />
          <div className="column5" />
          <div className="column6" />
          <div className="column7" />
          <div className="column8" />
          <div className="column9" />
          <div className="column10" />
          <div className="column11" />
          <div className="column12" />
          <div className="column13" />
          <div className="column14" />
          <div className="column15" />
          <div className="column16" />
          <div className="column17" />
          <div className="column18" />
          <div className="column19" />
          <div className="column20" />
          <div className="column21" />
          <div className="column22" />
          <div className="column23" />
          <div className="column24" />
          <div className="column25" />
          <div className="column26" />
          <div className="column27" />
          <div className="column28" />
          <div className="column29" />
          <div className="column30" />
          <div className="column31" />
          <div className="column32" />
          <div className="column33" />
          <div className="column34" />
          <div className="column35" />
          <div className="column36" />
          <div className="column37" />
          <div className="column38" />
          <div className="column39" />
          <div className="column40" />
          <div className="column41" />
          <div className="column42" />
          <div className="column43" />
          <div className="column44" />
          <div className="column45" />
          <div className="column46" />
          <div className="column47" />
          <div className="column48" />
          <div className="column49" />
          <div className="column50" />
          <div className="column51" />
          <div className="column52" />
          <div className="column53" />
          <div className="column54" />
          <div className="column55" />
          <div className="column56" />
          <div className="column57" />
          <div className="column58" />
          <div className="column59" />
          <div className="column60" />
          <div className="column61" />
          <div className="column62" />
          <div className="column63" />
          <div className="column64" />
          <div className="column65" />
          <div className="column66" />
          <div className="column67" />
          <div className="column68" />
          <div className="column69" />
          <div className="column70" />
          <div className="column71" />
          <div className="column72" />
        </div>
        <div className="line">
          <div className="bg4" />
          <div className="yellow-rectangle">
            <div className="cian" />
            <div className="yellow" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default WidgetLSizeTimelineCha;
